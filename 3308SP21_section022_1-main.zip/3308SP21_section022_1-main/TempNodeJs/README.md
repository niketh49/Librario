# masterEJS
<p>git clone https://github.com/petranb2/masterEJS.git</p>
<p>cd startEJS</p>
<p>Start your tutorial at <a href="https://medium.com/swlh/master-ejs-template-engine-with-node-js-and-expressjs-979cc22b69be">master-ejs-template-engine-with-node-js-and-expressjs</a><p>
