# Project Librario

We want to create a software application that allows users to keep track of which games they own in their collection. Historically people with large collections of games have been forced to use antiquated software such as Microsoft Excel, and Google Charts to keep track of which games they own. We want to create a fun and easy way for people to not only track, but share their game collections with others.
